package com.softwareag.de.s.gitjendis.builder.cli;

import javax.annotation.Nonnull;

import com.github.jochenw.afw.core.ILifecycleController;
import com.github.jochenw.afw.core.impl.DefaultLifecycleController;
import com.github.jochenw.afw.core.inject.ComponentFactoryBuilder.Module;
import com.github.jochenw.afw.core.inject.IComponentFactory;
import com.github.jochenw.afw.core.inject.simple.SimpleComponentFactoryBuilder;
import com.github.jochenw.afw.core.log.ILogFactory;
import com.github.jochenw.afw.core.props.IPropertyFactory;
import com.github.jochenw.afw.core.util.Functions.FailableSupplier;
import com.softwareag.de.s.gitjendis.builder.actions.TestBuildAction;
import com.github.jochenw.afw.core.util.Exceptions;
import com.github.jochenw.afw.core.util.Objects;


public class App {
	private static @Nonnull App instance = new App(null);

	private final Module module;
	private IComponentFactory componentFactory;
	private ILogFactory logFactory;
	private IPropertyFactory propertyFactory;
	private FailableSupplier<ILogFactory,?> logFactorySupplier;
	private FailableSupplier<IPropertyFactory,?> propertyFactorySupplier;
	
	protected App(Module pModule) {
		module = pModule;
	}

	public static synchronized void setInstance(@Nonnull App pInstance) {
		instance = Objects.requireNonNull(pInstance, "Instance");
	}

	public static synchronized @Nonnull App getInstance() {
		return instance;
	}

	public synchronized @Nonnull IComponentFactory getComponentFactory() {
		if (componentFactory == null) {
			componentFactory = newComponentFactory();
		}
		return Objects.requireNonNull(componentFactory);
	}

	protected @Nonnull IComponentFactory newComponentFactory() {
		final Module mod = newModule();
		return new SimpleComponentFactoryBuilder().module(mod).build();
	}

	protected @Nonnull Module newModule() {
		final ILifecycleController lc = new DefaultLifecycleController();
		final ILogFactory lf = getLogFactory();
		final IPropertyFactory pf = getPropertyFactory();
		return (b) -> {
			b.bind(ILifecycleController.class).toInstance(lc);
			b.bind(ILogFactory.class).toInstance(lf);
			b.bind(IPropertyFactory.class).toInstance(pf);
			b.bind(BuildAction.class, "test").to(TestBuildAction.class);
			if (module != null) {
				module.configure(b);
			}
		};
	}

	public synchronized void setLogFactory(@Nonnull FailableSupplier<ILogFactory,?> pSupplier) {
		logFactorySupplier = Objects.requireNonNull(pSupplier, "Supplier");
	}

	public synchronized void setPropertyFactory(@Nonnull FailableSupplier<IPropertyFactory,?> pSupplier) {
		propertyFactorySupplier = Objects.requireNonNull(pSupplier, "Supplier");
	}

	public synchronized @Nonnull ILogFactory getLogFactory() {
		if (logFactory == null) {
			if (logFactorySupplier == null) {
				throw new NullPointerException("No LogFactory supplier present.");
			}
			try {
				logFactory = logFactorySupplier.get();
			} catch (Throwable t) {
				throw Exceptions.show(t);
			}
		}
		return Objects.requireNonNull(logFactory);
	}

	public synchronized @Nonnull IPropertyFactory getPropertyFactory() {
		if (propertyFactory == null) {
			if (propertyFactorySupplier == null) {
				throw new NullPointerException("No PropertyFactory supplier present.");
			}
			try {
				propertyFactory = propertyFactorySupplier.get();
			} catch (Throwable t) {
				throw Exceptions.show(t);
			}
		}
		return Objects.requireNonNull(propertyFactory);
	}
}
