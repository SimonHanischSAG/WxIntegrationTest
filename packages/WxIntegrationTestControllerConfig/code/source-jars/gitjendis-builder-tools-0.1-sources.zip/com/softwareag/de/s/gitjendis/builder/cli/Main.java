package com.softwareag.de.s.gitjendis.builder.cli;

import java.io.IOException;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Nonnull;

import com.github.jochenw.afw.core.cli.ArgsHandler;
import com.github.jochenw.afw.core.inject.ComponentFactoryBuilder.Binder;
import com.github.jochenw.afw.core.inject.ComponentFactoryBuilder.Module;
import com.github.jochenw.afw.core.inject.IComponentFactory;
import com.github.jochenw.afw.core.io.IReadable;
import com.github.jochenw.afw.core.log.ILogFactory;
import com.github.jochenw.afw.core.log.app.DefaultAppLog;
import com.github.jochenw.afw.core.log.app.IAppLog;
import com.github.jochenw.afw.core.log.simple.SimpleLogFactory;
import com.github.jochenw.afw.core.props.DefaultPropertyFactory;
import com.github.jochenw.afw.core.props.IPropertyFactory;
import com.github.jochenw.afw.core.scripts.IScriptEngine.Script;
import com.github.jochenw.afw.core.util.Exceptions;
import com.github.jochenw.afw.core.util.Objects;
import com.github.jochenw.afw.core.util.Scripts;
import com.github.jochenw.afw.core.util.Streams;

public class Main extends ArgsHandler<Main.Options> {
	public static class Options {
		private Path srcDir, targetDir, globalProperties;
		private String action, buildNumber, jobName;

		public Path getSrcDir() { return srcDir; }
		public Path getTargetDir() { return targetDir; }
		public String getAction() { return action; }
		public String getBuildNumber() { return buildNumber; }
		public String getJobName() { return jobName; }
		public Path getGlobalProperties() { return globalProperties; }
	}

	@Override
	protected Options newOptionBean() {
		return new Options();
	}

	@Override
	protected RuntimeException error(String pMsg) {
		return usage(pMsg);
	}

	@Override
	protected void run(Options pOptions) throws Exception {
		final DefaultAppLog outLogger = new DefaultAppLog(System.out);
		final DefaultAppLog errLogger = new DefaultAppLog(System.err);
		final Module module = (b) -> {
			b.bind(Path.class, "srcDir").toInstance(pOptions.srcDir);
			b.bind(Path.class, "targetDir").toInstance(pOptions.targetDir);
			b.bind(String.class, "buildNumber").toInstance(pOptions.buildNumber);
			b.bind(String.class, "jobName").toInstance(pOptions.jobName);
			b.bind(IAppLog.class, "err").toInstance(errLogger);
			b.bind(IAppLog.class, "out").toInstance(outLogger);
			loadPlugins(b, pOptions);
		};
		final App app = new App(module);
		app.setLogFactory(() -> newLogFactory(pOptions));
		app.setPropertyFactory(() -> newPropertyFactory(pOptions));
		App.setInstance(app);
		final IComponentFactory componentFactory = app.getComponentFactory();
		final @Nonnull String actionName = Objects.requireNonNull(pOptions.getAction());
		final BuildAction action = componentFactory.requireInstance(BuildAction.class, actionName);
		outLogger.info("Running action: " + action.getClass().getName());
		action.run();
		outLogger.info("Finished action");
	}

	protected void loadPlugins(Binder pBinder, Options pOptions) {
		final Path pluginDir = Paths.get("/opt/GitJenDIS/etc/plugins");
		loadPlugins(pBinder, pluginDir, pOptions);
		final Path projectPluginDir = pOptions.srcDir.resolve(".build/plugins");
		loadPlugins(pBinder, projectPluginDir, pOptions);
	}

	protected void loadPlugins(Binder pBinder, Path pPluginDir, Options pOptions) {
		if (Files.isDirectory(pPluginDir)) {
			try {
				Files.walk(pPluginDir, 1).forEach((p) -> {
					if (Scripts.isScriptFile(p)) {
						final Script script = Scripts.compile(IReadable.of(p), StandardCharsets.UTF_8);
						final Map<String,Object> model = new HashMap<>();
						model.put("options", pOptions);
						final Module module = script.call(model);
						if (module == null) {
							throw new NullPointerException("Plugin script did not return a value: " + p);
						}
						module.configure(pBinder);
					}
				});
			} catch (IOException e) {
				throw Exceptions.show(e);
			}
		}
	}

	protected @Nonnull ILogFactory newLogFactory(Options pOptions) {
		return new SimpleLogFactory(System.out);
	}

	protected @Nonnull IPropertyFactory newPropertyFactory(Options pOptions) {
		final Properties properties = new Properties();
		final Path factoryProperties = Objects.notNull(pOptions.getGlobalProperties(),
													   Paths.get("/opt/GitJenDIS/etc/build.properties"));
		if (!Files.isRegularFile(factoryProperties)) {
			throw new IllegalStateException("Build property file not found: " + factoryProperties);
		}
		properties.putAll(Streams.load(factoryProperties));
		final Path projectProperties = pOptions.srcDir.resolve(".build/project.properties");
		if (!Files.isRegularFile(projectProperties)) {
			throw new IllegalStateException("Project property file not found: .build/project.properties");
		}
		properties.putAll(Streams.load(projectProperties));
		return new DefaultPropertyFactory(properties);
	}

	@Override
	protected Options parse(String[] pArgs) {
		final List<String> args = new ArrayList<>(Arrays.asList(pArgs));
		if (args.isEmpty()) {
			throw usage("No action given.");
		}
		final String action = args.remove(0);
		switch(action) {
		  case "validate":
		  case "build":
		  case "test":
		  case "archive":
		  case "deploy":
			  final String[] optionArgs = args.toArray(new String[args.size()]);
			  final Options options = super.parse(optionArgs);
			  if (options.srcDir == null) {
				  throw usage("Required option missing: -srcDir (Source, or project directory)");
			  }
			  if (options.targetDir == null) {
				  throw usage("Required option missing: -srcDir (Target, or build directory)");
			  }
			  if (options.buildNumber == null) {
				  throw usage("Required option missing: -buildNumber (Build number)");
			  }
			  if (options.jobName == null) {
				  throw usage("Required option missing: -jobName (Job name)");
			  }
			  options.action = action;
			  return options;
	      default:
	    	  throw usage("Invalid action: Expected validate|build|test|archive|deploy, got " + action);
		}
	}

	@Override
	protected void registerOptions(OptionRegistry<Options> pRegistry) {
		super.registerOptions(pRegistry);
		pRegistry.register((ctx,  bean, name, primaryName) -> {
			final Path srcDir = ctx.getSinglePathValue();
			if (!Files.isDirectory(srcDir)) {
				throw usage("Invalid argument for option " + name + ": Expected existing directory, got " + srcDir);
			}
			bean.srcDir = srcDir;
		}, "srcDir", "sd");
		pRegistry.register((ctx,  bean, name, primaryName) -> {
			bean.targetDir = ctx.getSinglePathValue();
		}, "targetDir", "td");
		pRegistry.register((ctx,  bean, name, primaryName) -> {
			bean.buildNumber = ctx.getSingleValue();
			try {
				Integer.parseInt(bean.buildNumber);
			} catch (NumberFormatException e) {
				throw usage("Invalid argument for option " + name + ": Expected integer number, got " + bean.buildNumber);
			}
		}, "buildNumber", "bn");
		pRegistry.register((ctx,  bean, name, primaryName) -> {
			bean.jobName = ctx.getSingleValue();
		}, "jobName", "jn");
		pRegistry.register((ctx, bean, name, primaryName) -> {
			final Path p = ctx.getSinglePathValue();
			if (!Files.isRegularFile(p)) {
				throw usage("Invalid argument for option " + name + ": Expected existing property file, got"
						    + p);
			}
			bean.globalProperties = p;
		}, "globalProperties", "gp");
	}

	public static void main(String[] pArgs) throws Exception {
		new Main().run(pArgs);
		System.exit(0);
	}

	public static RuntimeException usage(String pMsg) {
		final PrintStream ps = System.err;
		if (pMsg != null) {
			ps.println(pMsg);
			ps.println();
		}
		ps.println("Usage: java " + Main.class.getName() + " <action> <options>");
		ps.println();
		ps.println("Possible actions are: validate|build|test|archive|deploy");
		ps.println("Required options are:");
		ps.println("  -bn|-buildNumber <N> Sets the build number to <N>.");
		ps.println("  -jn|-jobName <N>     Sets the job name to <N>.");
		ps.println("  -sd|-srcDir <D>      Sets the source directory (project directory) to <D>.");
		ps.println("  -td|-targetDir <D>   Sets the target directory (build directory) to <D>.");
		ps.println("Possible options are:");
		ps.println("  -gp|-globalProperties <F> Sets the global properties file.");
		ps.println("                            The default value is /opt/GitJenDIS/etc/build.properties.");
		System.exit(1);
		return null;
	}
}
