package com.softwareag.de.s.gitjendis.builder.actions;

import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.annotation.Nonnull;
import javax.inject.Inject;
import javax.inject.Named;

import com.github.jochenw.afw.core.inject.IComponentFactory;
import com.github.jochenw.afw.core.inject.IComponentFactoryAware;
import com.github.jochenw.afw.core.inject.PropInject;
import com.github.jochenw.afw.core.log.app.IAppLog;
import com.github.jochenw.afw.core.props.IProperty;
import com.github.jochenw.afw.core.util.Exceptions;
import com.github.jochenw.afw.core.util.Files;
import com.github.jochenw.afw.core.util.Objects;
import com.softwareag.de.s.gitjendis.builder.cli.BuildAction;

public abstract class AbstractBuildAction implements BuildAction, IComponentFactoryAware {
	@PropInject(id="wm.home.dir") IProperty<String> wmHomeDirProperty;
	@Inject @Named(value="err")  protected IAppLog errorLogger;
	@Inject @Named(value="out")  protected IAppLog outLogger;
	private IComponentFactory componentFactory;
	private Project project;
	private IS builder;

	@Override
	public void init(IComponentFactory pFactory) {
		componentFactory = pFactory;
		project = new Project(this);
		final URL url;
		try {
			url = new URL("http://builder:5555/");
		} catch (MalformedURLException e) {
			throw Exceptions.show(e);
		}
		builder = new IS(url, "Administrator", "manage");
	}

	public @Nonnull IComponentFactory getComponentFactory() {
		return Objects.requireNonNull(componentFactory);
	}

	protected @Nonnull Path getSrcDir() {
		return getComponentFactory().requireInstance(Path.class, "srcDir");
	}

	protected @Nonnull Path getTargetDir() {
		return getComponentFactory().requireInstance(Path.class, "targetDir");
	}

	protected @Nonnull String getBuildNumber() {
		return getComponentFactory().requireInstance(String.class, "buildNumber");
	}

	protected @Nonnull String getJobName() {
		return getComponentFactory().requireInstance(String.class, "jobName");
	}

	protected @Nonnull Path getWmHomeDir() {
		final String wmHomeDirStr = wmHomeDirProperty.getValue();
		if (wmHomeDirStr == null) {
			throw new NullPointerException("Missing property: " + wmHomeDirProperty.getKey());
		}
		if (wmHomeDirStr.length() == 0) {
			throw new NullPointerException("Empty property: " + wmHomeDirProperty.getKey());
		}
		
		final Path wmHomeDir = Objects.requireNonNull(Paths.get(wmHomeDirStr));
		if (!Files.isDirectory(wmHomeDir)) {
			throw new IllegalStateException("Invalid value for property " + wmHomeDirProperty.getKey()
			                                + ": Expected existing directory, got " + wmHomeDirStr);
		}
		return wmHomeDir;
	}

	protected @Nonnull Project getProject() {
		return Objects.requireNonNull(project);
	}

	public static class IS {
		private final @Nonnull URL url;
		private final @Nonnull String userName, password;

		public IS(@Nonnull URL pUrl, @Nonnull String pUserName, @Nonnull String pPassword) {
			url = pUrl;
			userName = pUserName;
			password = pPassword;
		}
		
		public @Nonnull URL getUrl() { return url; }
		public @Nonnull String getUserName() { return userName; }
		public @Nonnull String getPassword() { return password; }
		public @Nonnull String getHost() { return Objects.requireNonNull(getUrl().getHost(), "Host"); }
		public int getPort() { return getUrl().getPort(); }
		public boolean isUsingSsl() { return "https".equals(getUrl().getProtocol()); }
	}

	protected @Nonnull IS getBuilder() {
		return Objects.requireNonNull(builder);
	}

	protected void error(String pMsg, Throwable pTh) {
		errorLogger.error(pMsg, pTh);
	}
}
