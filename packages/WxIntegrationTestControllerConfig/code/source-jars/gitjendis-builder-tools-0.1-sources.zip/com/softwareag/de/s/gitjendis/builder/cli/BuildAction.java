package com.softwareag.de.s.gitjendis.builder.cli;

public interface BuildAction extends Runnable {

}
