package com.softwareag.de.s.gitjendis.builder.cli;

import java.io.PrintStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.function.Predicate;

import com.github.jochenw.afw.core.cli.ArgsHandler;
import com.github.jochenw.afw.core.util.Exceptions;
import com.github.jochenw.afw.core.util.Files;
import com.github.jochenw.afw.core.util.Predicates;
import com.github.jochenw.afw.core.util.Strings;
import com.softwareag.de.s.gitjendis.builder.utils.TestSuiteRunner;

public class TestSuiteRunnerCli extends ArgsHandler<TestSuiteRunnerCli.Options> {
	public static class Options {
		private Path wmHomeDir, projectDir, testDir;
		private URL isUrl;
		private String isUser, isPassword, coverage;
		public Path getWmHomeDir() { return wmHomeDir; }
		public Path getProjectDir() { return projectDir; }
		public Path getTestDir() { return testDir; }
		public URL getIsUrl() { return isUrl; }
		public String getIsUser() {	return isUser; }
		public String getIsPassword() { return isPassword; }
		public boolean isDoingCoverage() { return coverage != null; }
	}

	@Override
	protected Options newOptionBean() {
		return new Options();
	}

	@Override
	protected RuntimeException error(String pMsg) {
		return usage(pMsg);
	}

	@Override
	protected Options parse(String[] pArgs) {
		final Options options = super.parse(pArgs);
		if (options.wmHomeDir == null) {
			throw usage("Required option missing: -wmHomeDir (webMethods home directory)");
		}
		if (options.projectDir == null) {
			options.projectDir = Paths.get(".");
		}
		if (options.testDir == null) {
			options.testDir = options.projectDir.resolve("target/test");
		}
		if (options.isUrl == null) {
			throw usage("Required option missing: -isUrl (IS test server's URL)");
		}
		if (options.isUser == null) {
			options.isUser = "Administrator";
		}
		if (options.isPassword == null) {
			options.isPassword = "manage";
		}
		return options;
	}

	@Override
	protected void registerOptions(OptionRegistry<Options> pRegistry) {
		super.registerOptions(pRegistry);
		pRegistry.register((ctx, bean, name, primaryName) -> {
			final Path p = ctx.getSinglePathValue();
			if (!Files.isDirectory(p)) {
				throw usage("Invalid value for option " + name + ": Expected existing directory, got " + p);
			}
			bean.wmHomeDir = p;
		}, "wmHomeDir", "wh");
		pRegistry.register((ctx, bean, name, primaryName) -> {
			final Path p = ctx.getSinglePathValue();
			if (!Files.isDirectory(p)) {
				throw usage("Invalid value for option " + name + ": Expected existing directory, got " + p);
			}
			bean.projectDir = p;
		}, "projectDir", "pd");
		pRegistry.register((ctx, bean, name, primaryName) -> {
			final Path p = ctx.getSinglePathValue();
			if (!Files.isDirectory(p)) {
				throw usage("Invalid value for option " + name + ": Expected existing directory, got " + p);
			}
			bean.testDir = p;
		}, "testDir", "td");
		pRegistry.register((ctx, bean, name, primaryName) -> {
			final String s = ctx.getSingleValue();
			final URL u;
			try {
				u = new URL(s);
			} catch (MalformedURLException e) {
				throw usage("Invalid value for option " + name + ": Expected valid URL, got " + s);
			}
			bean.isUrl = u;
		}, "isUrl", "ur");
		pRegistry.register((ctx, bean, name, primaryName) -> {
			bean.isUser = ctx.getSingleValue();
		}, "isUser", "us");
		pRegistry.register((ctx, bean, name, primaryName) -> {
			bean.isPassword = ctx.getSingleValue();
		}, "isPassword", "up");
		pRegistry.register((ctx, bean, name, primaryName) -> {
			bean.coverage = ctx.getSingleValue();
		}, "coverage", "co");
	}

	@Override
	protected void run(Options pOptions) throws Exception {
		final Predicate<String> predicate;
		final String coverage = pOptions.coverage;
		if (coverage == null) {
			predicate = Predicates.alwaysTrue();
		} else {
			predicate = Strings.matchers(coverage, ",");
		}
		new TestSuiteRunner(pOptions.getWmHomeDir()).run(pOptions.getProjectDir(), predicate, 
				                                         pOptions.getTestDir(), pOptions.getIsUrl(),
				                                         pOptions.getIsUser(), pOptions.getIsPassword(),
				                                         pOptions.isDoingCoverage());
	}

	public static void main(String[] pArgs) {
		TestSuiteRunnerCli r = new TestSuiteRunnerCli();
		final Options options = r.parse(pArgs);
		try {
			r.run(options);
		} catch (Throwable t) {
			throw Exceptions.show(t);
		}
	}

	public RuntimeException usage(String pMsg) {
		final PrintStream ps = System.err;
		if (pMsg != null) {
			ps.println(pMsg);
			ps.println();
		}
		//          01234567890123456789012345678901234567890123456789012345678901234567890123456789
		ps.println("Usage: java " + getClass().getName() + " <options>");
		ps.println();
		ps.println("Required options are:");
		ps.println(" -ur|-isUrl <U>     Sets the IS URL, where to run the tests. Assumes, that");
		ps.println("                    the test packages have been deployed in advance.");
		ps.println(" -wh|-wmHomeDir <D> Sets the webMethods home directory.");
		ps.println();
		ps.println("Other options are:");
		ps.println(" -co|-coverage <P>   Requests, that code coverage is being created for the");
		ps.println("                     packages. <P> is a comma separated list of package names,");
		ps.println("                     wildcards like *, or ? are permitted.");
		ps.println(" -pd|-projectDir <D> Sets the project directory, where to look for IS packages,");
		ps.println("                     and test suite files. Defaults to the current directory.");
		ps.println(" -td|-testDir <D>    Sets the test directory, where temporary files are being");
		ps.println("                     created. Defaults to the <PROJECT_DIR>/target/test.");
		ps.println(" -up|-isPassword <P> Sets the IS user password. Defaults to manage.");
		ps.println(" -us|-isUser <U>    Sets the IS user, which has permissions to invoke test");
		ps.println("                    services remotely. Defaults to Administrator.");
		System.exit(0);
		return null;
	}
}
