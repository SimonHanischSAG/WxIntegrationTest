/**
 * 
 */
/**
 * @author jwi
 *
 */
package com.github.jochenw.afw.core.log.app;