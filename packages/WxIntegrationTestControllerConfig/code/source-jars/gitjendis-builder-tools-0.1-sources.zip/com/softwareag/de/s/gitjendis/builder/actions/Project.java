package com.softwareag.de.s.gitjendis.builder.actions;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.annotation.Nonnull;

import com.github.jochenw.afw.core.data.Data;
import com.github.jochenw.afw.core.util.Exceptions;
import com.github.jochenw.afw.core.util.Files;
import com.github.jochenw.afw.core.util.Objects;
import com.github.jochenw.afw.core.util.Streams;

public class Project {
	public class Package {
		private final @Nonnull String name;
		private final @Nonnull Path dir;

		public Package(@Nonnull String pName, @Nonnull Path pDir) {
			name = Objects.requireNonNull(pName, "Name");
			dir = Objects.requireNonNull(pDir, "Dir");
		}
		public @Nonnull String getName() { return name; }
		public @Nonnull Path getDir() { return dir; }
	}

	private final @Nonnull AbstractBuildAction buildAction;
	private final @Nonnull Path projectDir;
	private final @Nonnull Properties properties;
	private List<Package> packages;

	protected Project(@Nonnull AbstractBuildAction pAction) {
		buildAction = Objects.requireNonNull(pAction, "Action");
		projectDir = buildAction.getSrcDir();
		final Path projectProperties = projectDir.resolve(".build/project.properties");
		if (!Files.isRegularFile(projectProperties)) {
			throw new IllegalStateException("Project property file not found: " + projectProperties);
		}
		properties = Objects.requireNonNull(Streams.load(projectProperties), "Properties");
	}

	public String getGroupId() {
		return (String) Data.requireString(properties, "project.groupId");
	}

	public String getVersion() {
		return (String) Data.requireString(properties, "project.version");
	}

	public String getProperty(String pKey) {
		return properties.getProperty(pKey);
	}

	public List<Package> getPackages() {
		if (packages == null) {
			packages = new ArrayList<>();
			final FileVisitor<Path> fv = new SimpleFileVisitor<Path>() {
				@Override
				public FileVisitResult visitFile(Path pFile, BasicFileAttributes pAttrs) throws IOException {
					final @Nonnull Path file = Objects.requireNonNull(pFile);
					final @Nonnull Path fileName = Objects.requireNonNull(file.getFileName());
					if ("manifest.v3".equals(fileName.toString())) {
						final Path dir = file.getParent();
						if (dir == null) {
							throw new NullPointerException("Parent directory is null for file: " + file);
						} else {
							final Path dirFileName = Objects.requireNonNull(Objects.requireNonNull(dir).getFileName());
							final String packageName = Objects.requireNonNull(dirFileName.toString());
							packages.add(new Package(packageName, dir));
						}
					}
					return super.visitFile(pFile, pAttrs);
				}
			};
			try {
				java.nio.file.Files.walkFileTree(projectDir, fv);
			} catch (IOException e) {
				throw Exceptions.show(e);
			}
		}
		return packages;
	}
}
