package com.softwareag.de.s.gitjendis.builder.actions;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import javax.annotation.Nonnull;

import com.github.jochenw.afw.core.inject.PropInject;
import com.github.jochenw.afw.core.props.IProperty;
import com.github.jochenw.afw.core.util.Exceptions;
import com.github.jochenw.afw.core.util.Files;
import com.github.jochenw.afw.core.util.Holder;
import com.github.jochenw.afw.core.util.Objects;
import com.github.jochenw.afw.core.util.Strings;
import com.github.jochenw.afw.core.util.Tupel;
import com.softwareag.de.s.gitjendis.builder.utils.FileUtils;
import com.softwareag.de.s.gitjendis.builder.utils.TestSuiteRunner;
import com.softwareag.de.s.gitjendis.builder.utils.TestSuiteRunner.TestSuiteFile;


public class TestBuildAction extends AbstractBuildAction {
	@PropInject(id="builder.is.url") IProperty<String> isUrl;
	@PropInject(id="builder.is.user") IProperty<String> isUser;
	@PropInject(id="builder.is.password") IProperty<String> isPassword;
	@PropInject(id="project.coverage", defaultValue="false") boolean coverageRequested;

	@Override	
	public void run() {
		outLogger.info("TestBuildAction.run: ->");
		final Path compositeRunnerDir = findCompositeRunnerDir();
		if (compositeRunnerDir == null) {
			throw new IllegalStateException("Unable to locate run-composite-runner.xml in wmHomeDir" + getWmHomeDir());
		}
		final Path testDir = createTestDirectory(compositeRunnerDir);
		final TestSuiteRunner runner = new TestSuiteRunner(getWmHomeDir());
		final List<Project.Package> packages = getDeployablePackages();
		final List<TestSuiteFile> testSuiteFiles = new ArrayList<>();
		final List<String> scopePackages = new ArrayList<>();
		for (Project.Package pkg : packages) {
			findTestSuiteFiles(pkg, (t) -> {
				final Path p = t.getAttribute1();
				final String pname = t.getAttribute2();
				testSuiteFiles.add(new TestSuiteFile(p, pname));
			});
			scopePackages.add(pkg.getName());
		}
		if (testSuiteFiles.isEmpty()) {
			outLogger.info("TestBuilAction.run: No testsuite files found.");
		} else {
			outLogger.info("TestBuildAction.run: Found " + testSuiteFiles.size() + " testsuite files:");
			testSuiteFiles.forEach((TestSuiteFile tsf) -> {
				outLogger.info(tsf.getPackageDir().getFileName().toString() + ": " + tsf.getTestSuiteFile());
			});
			runner.run(testSuiteFiles, scopePackages, getSrcDir(), testDir,
					   getIsUrl(), getIsUser(), getIsPassword(), isDoingCoverage());
		}
		outLogger.info("TestBuildAction.run: <-");
	}

	private @Nonnull Path createTestDirectory(final Path pCompositeRunnerDir) {
		final @Nonnull Path testDir = Objects.requireNonNull(getTargetDir().resolve("test"));
		FileUtils.getInstance().copyDirectory(pCompositeRunnerDir, testDir);
		return testDir;
	}

	protected Path findCompositeRunnerDir() {
		final Path designerDir = getWmHomeDir().resolve("Designer");
		if (!Files.isDirectory(designerDir)) {
			return designerDir;
		}
		final Holder<Path> holder = new Holder<>();
		final FileVisitor<Path> fv = new SimpleFileVisitor<Path>() {
			@Override
			public FileVisitResult preVisitDirectory(Path pDir, BasicFileAttributes pAttrs) throws IOException {
				final Path runCompositeRunnerXml = pDir.resolve("run-composite-runner.xml");
				if (Files.isRegularFile(runCompositeRunnerXml)) {
					holder.set(pDir);
					return FileVisitResult.TERMINATE;
				}
				return FileVisitResult.CONTINUE;
			}
		};
		try {
			java.nio.file.Files.walkFileTree(designerDir, fv);
		} catch (Throwable t) {
			throw Exceptions.show(t);
		}
		return holder.get();
	}

	protected List<Project.Package> getTestPackages() {
		return getDeployablePackages();
	}

	protected List<Project.Package> getDeployablePackages() {
		final String matcherStr = Objects.notNull(getProject().getProperty("is.deployablePackages"), "!**/*_Test");
		final Predicate<String> matcher = Strings.matchers(matcherStr, ",");
		final List<Project.Package> allPackages = getProject().getPackages();
		return allPackages.stream().filter((p) -> matcher.test(p.getDir().toString())).collect(Collectors.toList());
	}

	protected void findTestSuiteFiles(Project.Package pPkg, Consumer<Tupel<Path,String>> pConsumer) {
		final Path packageDir = pPkg.getDir();
		final FileVisitor<Path> fv = new SimpleFileVisitor<Path>() {
			@Override
			public FileVisitResult visitFile(Path pFile, BasicFileAttributes pAttrs) throws IOException {
				if (pAttrs.isRegularFile()  &&  TestSuiteRunner.isTestSuiteFile(pFile, (s) -> error(s, null))) {
					final String relativePath = packageDir.relativize(pFile).toString().replace('\\', '/');
					pConsumer.accept(new Tupel<Path,String>(packageDir, relativePath));
				}
				return FileVisitResult.CONTINUE;
			}
		};
		try {
			java.nio.file.Files.walkFileTree(getSrcDir(), fv);
		} catch (Throwable t) {
			throw Exceptions.show(t);
		}
	}

	protected @Nonnull URL getIsUrl() {
		final String isUrlStr = isUrl.getStringValue();
		if (isUrlStr == null) {
			throw new NullPointerException("Missing property: " + isUrl.getKey());
		}
		if (isUrlStr.length() == 0) {
			throw new IllegalArgumentException("Empty property: " + isUrl.getKey());
		}
		try {
			return new URL(isUrlStr);
		} catch (MalformedURLException e) {
			throw new IllegalArgumentException("Invalid value for property " + isUrl.getKey() + ": Expected valid URL, got " + isUrlStr);
		}
	}

	protected String getIsUser() {
		final String isUserStr = isUser.getStringValue();
		if (isUserStr == null) {
			throw new NullPointerException("Missing property: " + isUser.getKey());
		}
		if (isUserStr.length() == 0) {
			throw new IllegalArgumentException("Empty property: " + isUser.getKey());
		}
		return isUserStr;
	}

	protected String getIsPassword() {
		final String isPwdStr = isPassword.getStringValue();
		if (isPwdStr == null) {
			throw new NullPointerException("Missing property: " + isPassword.getKey());
		}
		if (isPwdStr.length() == 0) {
			throw new IllegalArgumentException("Empty property: " + isPassword.getKey());
		}
		return isPwdStr;
	}

	protected boolean isDoingCoverage() {
		return coverageRequested;
	}
}
