package com.softwareag.de.s.gitjendis.builder.utils;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;

import com.github.jochenw.afw.core.util.Exceptions;

public class FileUtils {
	private static final FileUtils THE_INSTANCE = new FileUtils();
	public static FileUtils getInstance() { return THE_INSTANCE; }

	public void copyDirectory(Path pSourceDir, Path pTargetDir) {
		try {
			Files.createDirectories(pTargetDir);
			final FileVisitor<Path> fv = new SimpleFileVisitor<Path>() {
				@Override
				public FileVisitResult visitFile(Path pFile, BasicFileAttributes pAttrs) throws IOException {
					final Path relativePath = pSourceDir.relativize(pFile);
					final Path targetFile = pTargetDir.resolve(relativePath);
					final Path dir = targetFile.getParent();
					if (dir != null) {
						Files.createDirectories(dir);
					}
					Files.deleteIfExists(targetFile);
					Files.copy(pFile, targetFile);
					return FileVisitResult.CONTINUE;
				}
			};
			Files.walkFileTree(pSourceDir, fv);
		} catch (Throwable t) {
			throw Exceptions.show(t);
		}
	}
}
